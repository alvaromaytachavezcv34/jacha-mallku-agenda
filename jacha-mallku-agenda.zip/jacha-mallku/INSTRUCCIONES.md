# 🦅 JACH'A MALLKU — Agenda Digital

Agenda de contratos y eventos con sincronización en tiempo real para todos los integrantes del grupo.

---

## 📋 PASOS PARA PONERLA EN LÍNEA

### PASO 1 — Crear proyecto en Firebase (base de datos gratuita)

1. Andá a **https://console.firebase.google.com**
2. Hacé clic en **"Crear un proyecto"**
3. Nombre del proyecto: `jacha-mallku` → Siguiente → Crear proyecto
4. En el menú izquierdo, hacé clic en **Firestore Database**
5. Clic en **"Crear base de datos"**
6. Elegí **"Comenzar en modo de prueba"** → Siguiente → Listo
7. Volvé al inicio del proyecto (ícono 🏠)
8. Hacé clic en el ícono **"</>"** (Agregar app web)
9. Nombre de la app: `agenda` → Registrar app
10. **Copiá los datos que aparecen** — los necesitás para el siguiente paso:
    ```
    apiKey: "...",
    authDomain: "...",
    projectId: "...",
    storageBucket: "...",
    messagingSenderId: "...",
    appId: "..."
    ```

---

### PASO 2 — Pegar tus credenciales en el archivo firebase.js

Abrí el archivo `src/firebase.js` y reemplazá cada valor:

```js
const firebaseConfig = {
  apiKey:            "PEGA_TU_apiKey_AQUI",       ← reemplazá con el tuyo
  authDomain:        "PEGA_TU_authDomain_AQUI",
  projectId:         "PEGA_TU_projectId_AQUI",
  storageBucket:     "PEGA_TU_storageBucket_AQUI",
  messagingSenderId: "PEGA_TU_messagingSenderId_AQUI",
  appId:             "PEGA_TU_appId_AQUI",
};
```

---

### PASO 3 — Subir el código a GitHub

1. Creá cuenta gratis en **https://github.com**
2. Clic en **"New repository"** (botón verde)
3. Nombre: `jacha-mallku-agenda` → **Create repository**
4. Descargá e instalá **GitHub Desktop** desde https://desktop.github.com
5. En GitHub Desktop: **File → Add local repository** → seleccioná esta carpeta
6. Escribí un mensaje (ej: "primera versión") → clic en **"Commit to main"**
7. Clic en **"Publish repository"** → Publish

---

### PASO 4 — Publicar en Vercel (gratis, en internet)

1. Andá a **https://vercel.com**
2. Clic en **"Sign up"** → elegí **"Continue with GitHub"**
3. Autorizá Vercel
4. Clic en **"Add New Project"**
5. Buscá `jacha-mallku-agenda` y hacé clic en **"Import"**
6. No cambies nada → clic en **"Deploy"**
7. Esperá ~2 minutos...
8. ¡Listo! Vercel te da un link tipo: `jacha-mallku-agenda.vercel.app`

**Compartí ese link con todos los integrantes del grupo.**
Cada vez que alguien agrega o edita un evento, todos lo ven al instante.

---

## 🔄 Actualizar la agenda en el futuro

Si necesitás cambiar algo en el código:
1. Editá los archivos
2. En GitHub Desktop: escribí el cambio → Commit → Push
3. Vercel actualiza el sitio automáticamente en ~1 minuto

---

## ❓ Preguntas frecuentes

**¿Es gratis?**
Sí. Firebase (hasta 20.000 escrituras/día) y Vercel son gratuitos para este uso.

**¿Funciona en celular?**
Sí, la agenda es responsive y funciona en cualquier dispositivo.

**¿Quién puede agregar eventos?**
Cualquier persona que tenga el link. Si querés restringir el acceso, avisá y agregamos contraseña.
